variable = "Hello World !"
print(variable)

Number = 10
print("Integer data Type :- ")
print(Number)

Float = 14.10
print("Float data Type :- ")
print(Float)

Boolean = True
print("Boolean data Type :- ")
print(Boolean)

none = None
print("None data Type :- ")
print(none)